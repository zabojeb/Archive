#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import time
import serial
import math
from cobs import cobs, cobsr
import os
import roslib
import sys
import rospy
import numpy as np
from std_msgs.msg import String, UInt16
from sensor_msgs.msg import Image, CompressedImage
from geometry_msgs.msg import Twist, Point, Quaternion

radio = serial.Serial()

radio.port = "/dev/serial/by-id/usb-Silicon_Labs_CP2102_USB_to_UART_Bridge_Controller_0001-if00-port0"

radio.baudrate = 19200 #// 2
radio.bytesize = 8
radio.timeout = 50
radio.write_timeout = None
radio.drsdtr = False
radio.dtr = False
radio.parity = "N"

radio.open()

# RECEIVE FROM RADIO
# MOVER
move = rospy.Publisher('cmd_vel', Twist, queue_size=10)
rospy.init_node('commander')
r = rospy.Rate(100) 

move_cmd = Twist()

def domove(z,x):
    move_cmd.linear.x = x
    move_cmd.angular.z = z

    move.publish(move_cmd)

# BUTTON
btn = rospy.Publisher('led1', String, queue_size = 10)
#rospy.init_node('commander.led')

#btn_cmd = String()

def button(toggle):
    if toggle == 1:
        btn.publish("data: 'on'")

# GRABBER
cam = rospy.Publisher('servo_camera', UInt16, queue_size = 10)
up = rospy.Publisher('servo_up', UInt16, queue_size = 10)
mag = rospy.Publisher('servo_catch', UInt16, queue_size = 10)
#uper = rospy.Subscriber("servo_up", UInt16)


#axis = 0
def grabber(camera, updown, magnet):
    #grab.publish(davka)
    #axis = updown
    #uper.data = axis
    cam.publish(int(camera))
    up.publish(int(updown))
    if magnet == 1:
        mag.publish(0)
    else:
        mag.publish(55)



# MAIN
while True:
    #r.sleep()
    #data = list(np.frombuffer(radio.read_until(b'split')[:-5], dtype = np.uint8))
    #data = list(np.frombuffer(radio.read(48), dtype = np.uint))
    #print(data)
    #max_speed = int(data[5]) * 0.8 / 100
    #domove(float(data[0]) * max_speed, float(data[1]) *  max_speed)
    #button(int(data[4]))
    try:
        while True:
            data = radio.read_until(b'\r\n')
            #if 19 < len(data) < 25: break
            arr = data.decode("utf-8").replace('\r\n', '').replace('(', '').replace(')','').split(';')
            arr.pop(-1)
            if 18 < len(data) < 25 and len(arr) == 8: break
            
    except UnicodeDecodeError: continue; print('fck unicode')
    try: arr = [int(item) for item in arr]
    except ValueError: continue; print('fck value')

    print(arr)

    try:
        max_speed = arr[7] * 0.8 / 100
        print(arr[7] * 0.8 / 100)
        domove((arr[3] - 48) * 2 * max_speed / 100, (arr[4] - 48) * 2 * max_speed / 100)
        print((arr[3] - 48) * 2 * max_speed / 100, (arr[4] - 48) * 2 * max_speed / 100)
        button(arr[6])
        grabber((arr[1] / 99 + 1) * 45, arr[0] / 99 * 90, arr[2])
        print(arr[1] / 99 * 90, arr[0] / 99 * 150)

    except IndexError: continue; print('fck index')
