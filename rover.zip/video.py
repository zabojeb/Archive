#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import time
import serial
import math
from PIL import Image as im
from cobs import cobs, cobsr
import os
import roslib
import sys
import rospy
import cv2
import numpy as np
from std_msgs.msg import String, UInt16
from sensor_msgs.msg import Image, CompressedImage
from geometry_msgs.msg import Twist, Point, Quaternion
from cv_bridge import CvBridge

bridge = CvBridge()

radio = serial.Serial()

radio.port = "/dev/serial/by-id/usb-Silicon_Labs_CP2102_USB_to_UART_Bridge_Controller_0001-if00-port0"

radio.baudrate = 19200 #// 2
radio.bytesize = 8
radio.timeout = 50
radio.write_timeout = None
radio.drsdtr = False
radio.dtr = False
radio.parity = "N"

radio.open()

def radios(data):
    rospy.Rate(5)
    line = bridge.imgmsg_to_cv2(data, "bgr8")
    #scale_percent = 20

    #width = int(line.shape[1] * scale_percent / 100)
    #height = int(line.shape[0] * scale_percent / 100)

    dsize = (100, 100)

    line = cv2.resize(line, dsize)
    #lines = line

    lines = cv2.cvtColor(line, cv2.COLOR_BGR2GRAY)
    cv2.imwrite('compressed.jpg', lines, [int(cv2.IMWRITE_JPEG_QUALITY), 50])
    new = cv2.imencode('.jpg', cv2.imread('compressed.jpg', 0))[1].tobytes()
    #x, y = 33, 44
    #x2, y2 = math.floor(x-50), math.floor(y-20)
    #lines = lines.resize((x2,y2),im.ANTIALIAS)
    
    bytesz = len(new)
    print(len(new))
    #time.sleep(0.15)
    radio.write((str(bytesz) + '\n').encode())  # ITS IMPORTANT
    print('SENDED')
    print(lines)
    radio.timeout = 50

    time.sleep(20)

    bytesarr = [new[i:i + 100] for i in range(0, len(new), 100)]
    for elem in bytesarr:
        radio.write(elem)
        time.sleep(0.05)

    print('full image sended')

def listener():
    rospy.init_node('final')
    rospy.Subscriber("front_camera/image_raw", Image, radios, queue_size=1)

while True:
    listener()