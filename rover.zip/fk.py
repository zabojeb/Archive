#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import time
import serial
from cobs import cobs, cobsr

import roslib
import sys
import rospy
import cv2
import numpy as np
from std_msgs.msg import String, UInt16
from sensor_msgs.msg import Image, CompressedImage
from geometry_msgs.msg import Twist, Point, Quaternion

radio = serial.Serial()

radio.port = "/dev/serial/by-id/usb-Silicon_Labs_CP2102_USB_to_UART_Bridge_Controller_0001-if00-port0"

radio.baudrate = 9600
radio.bytesize = 8
radio.timeout = 25
radio.write_timeout = 0
radio.rtscts = True
radio.dsrdtr = True
radio.parity = "N"

radio.open()

radio.write(b'\xaa\xfa\x01')
time.sleep(0.1)
print(radio.read(2))
