#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import time
import serial
import math
from PIL import Image as im
from cobs import cobs, cobsr
import os
import roslib
import sys
import rospy
import cv2
import numpy as np
from std_msgs.msg import String, UInt16
from sensor_msgs.msg import Image, CompressedImage
from geometry_msgs.msg import Twist, Point, Quaternion
from cv_bridge import CvBridge

bridge = CvBridge()

radio = serial.Serial()

radio.port = "/dev/serial/by-id/usb-Silicon_Labs_CP2102_USB_to_UART_Bridge_Controller_0001-if00-port0"

radio.baudrate = 19200 #// 2
radio.bytesize = 8
radio.timeout = 15
radio.write_timeout = None
radio.drsdtr = False
radio.dtr = False
radio.parity = "N"

radio.open()

# VIDEO RECEIVE FROM TOPIC

# RECEIVE FROM RADIO
# MOVER
move = rospy.Publisher('cmd_vel', Twist, queue_size=10)
rospy.init_node('commander')
r = rospy.Rate(100) 

move_cmd = Twist()

def domove(z,x):
    move_cmd.linear.x = x
    move_cmd.angular.z = z

    move.publish(move_cmd)

# BUTTON
btn = rospy.Publisher('led_rover', UInt16, queue_size = 10)
#rospy.init_node('commander.led')

#btn_cmd = String()

def button(toggle):
    btn.publish(int(toggle))

# GRABBER
cam = rospy.Publisher('servo_camera', UInt16, queue_size = 10)
up = rospy.Publisher('servo_up', UInt16, queue_size = 10)
mag = rospy.Publisher('servo_catch', UInt16, queue_size = 10)
#uper = rospy.Subscriber("servo_up", UInt16)


#axis = 0
def grabber(camera, updown, magnet):
    #grab.publish(davka)
    #axis = updown
    #uper.data = axis
    cam.publish(int(camera))
    up.publish(int(updown))
    if magnet == 1:
        mag.publish(0)
    else:
        mag.publish(55)



 
# END OF MAIN THINGS

def commander():
    rospy.Rate(10)
    try:
        while True:
            data = radio.read_until(b'\r\n')
                 #if 19 < len(data) < 25: break
            arr = data.decode("utf-8").replace('\r\n', '').replace('(', '').replace(')','').split(';')
            arr.pop(-1)
            if 18 < len(data) < 25 and len(arr) == 8: break
            
    except UnicodeDecodeError: print('fck unicode'); commander(); return
    try: arr = [int(item) for item in arr]
    except ValueError: print('fck value'); commander(); return

    print(arr)

    try:
        max_speed = arr[7] * 0.8 / 100
        print(arr[7] * 0.8 / 100)
        domove((arr[3] - 48) * 2 * max_speed / 100, (arr[4] - 48) * 2 * max_speed / 100)
        print((arr[3] - 48) * 2 * max_speed / 100, (arr[4] - 48) * 2 * max_speed / 100)
        button(arr[6])
        grabber((arr[1] / 99 + 1) * 45, arr[0] / 99 * 90, arr[2])
        print(arr[1] / 99 * 90, arr[0] / 99 * 150)
    except IndexError: print('fck index'); commander(); return


def image_to_bts(frame):
    _, bts = cv2.imencode('.jpg', frame)
    bts = bts.tostring()
    return bts

def radios(data):
    rospy.Rate(1)
    line = bridge.imgmsg_to_cv2(data, "bgr8")
    #scale_percent = 20

    #width = int(line.shape[1] * scale_percent / 100)
    #height = int(line.shape[0] * scale_percent / 100)

    dsize = (100, 100)

    line = cv2.resize(line, dsize)
    #lines = line

    lines = cv2.cvtColor(line, cv2.COLOR_BGR2GRAY)
    cv2.imwrite('compressed.jpg', lines, [int(cv2.IMWRITE_JPEG_QUALITY), 50])
    #new = cv2.imencode('.jpg', cv2.imread('compressed.jpg', 0))
    wer = cv2.imread('compressed.jpg', 0)
    new = image_to_bts(wer)
    #x, y = 33, 44
    #x2, y2 = math.floor(x-50), math.floor(y-20)
    #lines = lines.resize((x2,y2),im.ANTIALIAS)
    
    bytesz = len(new)
    print(len(new))
    #time.sleep(0.15)
    #radio.write((str(bytesz) + '\n').encode())  # ITS IMPORTANT
    print('SENDED')
    print(lines)
    radio.timeout = 50
    print(lines.shape)
    #time.sleep(1)

    bytesarr = [new[i:i + 128] for i in range(0, len(new), 128)]
    for elem in bytesarr:
        radio.write(elem)
        time.sleep(0.15)

    print('full image sended')
    
    #time.sleep(0.25)
    '''
    s = lines.tobytes()
    itog = [s[i:i + 128] for i in range(0, len(s), 128)]
    for elem in itog:
        radio.write(elem)
        time.sleep(0.05)
    '''
    #for elem in lines:
        #radio.write(elem.tobytes())
        #time.sleep(0.05)
        #commander()
    
    #print(np.shape(lines))

    # >>>>>>>>>> COMMANDER >>>>>>>>>>
    #time.sleep(0.05)
    commander()
    time.sleep(0.25)

def listener():
    #rospy.init_node('final')
    rospy.Subscriber("front_camera/image_raw", Image, radios, queue_size=1)
    '''
    print("<<< LISTENER COMPLETED <<<")
    time.sleep(0.15)
    
    commander()
    print(">>> COMMANDER COMPLETED >>>")
    time.sleep(0.2)
    '''
    #rospy.spin()

#rospy.init_node('final')
#rospy.spin()
listener()
while not rospy.is_shutdown:
    listener()
'''
while not rospy.is_shutdown():
    listener()fromstring
    
    print("<<< LISTENER COMPLETED <<<")
    time.sleep(0.15)
    commander()
    time.sleep(0.15)
'''
   
# IMAGE > NUMPY > MANY NUMPY > BYTES > COBS ENCODE > RADIO
# IMAGE > NUMPY > MANY NUMPY > BYTES > COBS ENCODE > RADIO > COBS DECODE ~ > NUMPY > IMAGE

# SECOND 2
