#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import time
import serial
from cobs import cobs, cobsr

import roslib
import sys
import rospy
import cv2
import numpy as np
from std_msgs.msg import String, UInt16
from sensor_msgs.msg import Image, CompressedImage
from geometry_msgs.msg import Twist, Point, Quaternion
'''
com = serial.Serial()
com.port = ("/dev/ttyACM0")
com.baudrate = 19200
com.bytesize = 8
com.timeout = None
com.open()
'''

radio = serial.Serial()

radio.port = '/dev/ttyUSB0'
radio.baudrate = 19200
radio.bytesize = 8
radio.timeout = None
radio.write_timeout = 0
radio.drsdtr = False
radio.dtr = False
radio.parity = "N"

radio.open()


rospy.init_node('omg')


def comdata():
    print('start')
    #data = com.read_until(b'\r\n')
    data = b'48;48;0;99;99;0;0;50;x\r\n'
    print(data)
    radio.write(data)
    time.sleep(0.005)
    print(np.array(data).nbytes)
    print(len(data))

def dosomething():
  try:
    oth = int(radio.readline().decode()) # - 1
    print(oth)
  except UnicodeDecodeError: return

  time.sleep(0.01)
  radio.timeout = 50

  img2 = list(np.frombuffer(radio.read(oth), dtype=np.uint8))
  res = [img2[i:i+len(img2)//100] for i in range(0, len(img2), len(img2)//100)]

  itog = res

  print(np.shape(np.array(itog)))
  print(np.array(itog))
  cv2.imwrite("main.jpg", np.array(itog))

while not rospy.is_shutdown():
  dosomething()
  time.sleep(0.2)
  print('a')
  comdata()
  time.sleep(0.15)
  print('b')
  rospy.spin()

# RADIO > COBS DECODE ~ > BYTES > NUMPY > IMAGE
# IMAGE > NUMPY > MANY NUMPY > BYTES > COBS ENCODE > RADIO > COBS DECODE ~ > NUMPY

# FIRST 1
