#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import time
import serial
from cobs import cobs, cobsr

import roslib
import sys
import rospy
import cv2
import numpy as np
from std_msgs.msg import String
from sensor_msgs.msg import Image, CompressedImage
from geometry_msgs.msg import Twist, Point, Quaternion

com = serial.Serial()

com.port = '/dev/ttyUSB0'
com.baudrate = 19200
com.bytesize = 8
com.timeout = None
com.write_timeout = 0
com.drsdtr = False
com.dtr = False
com.parity = "N"

com.open()


def dosomething():
  try:
    oth = int(com.readline().decode()) # - 1
    print(oth)
  except UnicodeDecodeError: print('lol'); return
  time.sleep(0.05)
  com.timeout = 50

  img2 = list(np.frombuffer(com.read(oth), dtype=np.uint8))
  res = [img2[i:i+len(img2)//100] for i in range(0, len(img2), len(img2)//100)]

  itog = res
  #for el in res:
    #itog.append([el[i:i + 3] for i in range(0, len(el), 3)])

  print(np.shape(np.array(itog)))
  print(np.array(itog))
  cv2.imwrite("main.jpg", np.array(itog))
  #cv2.namedWindow("main")
  #cv2.imshow("main", np.array(itog))
  #cv2.resizeWindow('main', 1900, 1900)
  #cv2.waitKey(1)
  #print(len(res), len(res[0]))
  #time.sleep(0.5)
  
while True:
  dosomething()
  #time.sleep(0.1)


# RADIO > COBS DECODE ~ > BYTES > NUMPY > IMAGE
# IMAGE > NUMPY > MANY NUMPY > BYTES > COBS ENCODE > RADIO > COBS DECODE ~ > NUMPY
