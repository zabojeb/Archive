#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import time
import serial
import math
from PIL import Image as im
from cobs import cobs, cobsr
import os
import roslib
import sys
import rospy
import cv2
import numpy as np
from std_msgs.msg import String
from sensor_msgs.msg import Image, CompressedImage
from geometry_msgs.msg import Twist, Point, Quaternion
from cv_bridge import CvBridge

bridge = CvBridge()

com = serial.Serial()

com.port = "/dev/serial/by-id/usb-Silicon_Labs_CP2102_USB_to_UART_Bridge_Controller_0001-if00-port0"

com.baudrate = 19200
com.bytesize = 8
com.timeout = None
com.write_timeout = 0
com.drsdtr = False
com.dtr = False
com.parity = "N"

com.open()

# VIDEO RECEIVE FROM TOPIC

def radio(data):
    line = bridge.imgmsg_to_cv2(data, "bgr8")
    #scale_percent = 20

    #width = int(line.shape[1] * scale_percent / 100)
    #height = int(line.shape[0] * scale_percent / 100)

    dsize = (100, 100)

    line = cv2.resize(line, dsize)
    #lines = line

    lines = cv2.cvtColor(line, cv2.COLOR_BGR2GRAY)
    #x, y = 33, 44
    #x2, y2 = math.floor(x-50), math.floor(y-20)
    #lines = lines.resize((x2,y2),im.ANTIALIAS)

    bytesz = 0
    for elem in lines:
        for x in elem:
            bytesz += x.nbytes

    #time.sleep(0.15)
    com.write((str(bytesz) + '\n').encode())  # ITS IMPORTANT
    print('SENDED')
    print(lines)
    com.timeout = 50

    time.sleep(0.075)
    
    '''
    s = lines.tobytes()
    itog = [s[i:i + 128] for i in range(0, len(s), 128)]
    for elem in itog:
        com.write(elem)
        time.sleep(0.05)
    '''

    for elem in lines:
        com.write(elem.tobytes())
        time.sleep(0.07)
    
    print(np.shape(lines))
    #com.read_until(str.encode('SpLiT'))

    #
    #print(len(lines))
    #print(len(lines[0]))

# END OF MAIN THINGS

def listener():
    rospy.init_node('send')
    rospy.Rate(0.5)
    rospy.Subscriber("front_camera/image_raw", Image, radio)
    #time.sleep(1)
    rospy.spin()



while not rospy.is_shutdown():
    listener()
    print("NOR")
    #time.sleep(0.25)
    
   
# IMAGE > NUMPY > MANY NUMPY > BYTES > COBS ENCODE > RADIO
# IMAGE > NUMPY > MANY NUMPY > BYTES > COBS ENCODE > RADIO > COBS DECODE ~ > NUMPY > IMAGE
