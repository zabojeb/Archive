import time
import serial
#from cobs import cobs

com = serial.Serial()

com.port = '/dev/ttyUSB0'
com.baudrate = 9600
com.bytesize = 8
com.timeout = 1
com.drsdtr = False
com.dtr = False
com.parity = "N"

com.open()

data = "" 
while True:
    print(com.read(1))
