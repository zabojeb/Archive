from random import randint

with open('sample.txt', 'w') as f:
    for i in range(1024*5):
        f.write(''.join(random.choice(string.ascii_uppercase + string.digits) for _ in range(randint(1,32))) + '\n')
