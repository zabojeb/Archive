import time
import serial

from cobs import cobs, cobsr

com = serial.Serial()

com.port = "/dev/ttyUSB0"
com.baudrate = 9600
com.bytesize = 8
com.timeout = None
com.write_timeout = 0
com.drsdtr = False
com.dtr = False
com.parity = "N"

com.open()

# FILE WORK HERE

file1 = open("/home/rosuser/Desktop/sample.txt", "r")

line = file1.read()

file1.close()

lines = [line[i:i+64] for i in range (0,len(line), 64)]

# RADIO
'''
com.write((str(len(lines) - 1) + '\n').encode())
time.sleep(1)

com.write((str(len(lines[-1])) + '\n').encode())
time.sleep(1)
'''
time.sleep(1)
com.write((str(len(line)) + '\n').encode())
time.sleep(0.25)
print(len(line))

com.timeout = 12

for i in lines[:-1]:
    com.write(str.encode(i))
    time.sleep(0.1)
time.sleep(0.15)
com.write(str.encode(lines[-1]))