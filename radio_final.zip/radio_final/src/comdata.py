#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import time
import serial
import math
from PIL import Image as im
from cobs import cobs, cobsr
import os
import roslib
import sys
import rospy
import cv2
import numpy as np
from std_msgs.msg import String
from sensor_msgs.msg import Image, CompressedImage
from geometry_msgs.msg import Twist, Point, Quaternion
from cv_bridge import CvBridge

com = serial.Serial()
com.port = ("/dev/ttyACM0")
com.baudrate = 19200
com.bytesize = 8
com.timeout = None
com.open()


radio = serial.Serial()

radio.port = '/dev/ttyUSB0'
radio.baudrate = 9600
radio.bytesize = 8
radio.timeout = 15
radio.write_timeout = None
radio.drsdtr = False
radio.dtr = False
radio.parity = "N"

radio.open()
#rospy.init_node('send_commands_radio')

while True:
    print('start')
    data = com.read_until(b'\r\n')
    print(data)
    radio.write(data)
    print('got it')
    #print(np.array(data).nbytes)
    # TIME TO VIDEO
    
    #time.sleep(1)
    

#x(0,99);y(0,99);button(0;1);max_speed(0,99);x