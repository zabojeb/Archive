#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import time
import serial
import math
from PIL import Image as im
from cobs import cobs, cobsr
import os
import roslib
import sys
import rospy
import cv2
import numpy as np
from std_msgs.msg import String
from sensor_msgs.msg import Image, CompressedImage
from geometry_msgs.msg import Twist, Point, Quaternion
from cv_bridge import CvBridge

bridge = CvBridge()

radioport = serial.Serial()

radioport.port = "/dev/serial/by-id/usb-Silicon_Labs_CP2102_USB_to_UART_Bridge_Controller_0001-if00-port0"

radioport.baudrate = 9600
radioport.bytesize = 8
radioport.timeout = None
radioport.write_timeout = 0
radioport.drsdtr = False
radioport.dtr = False
radioport.parity = "N"

radioport.open()

# COM DATA

com = serial.Serial()
com.port = ("COM3")


# IMAGE > NUMPY > MANY NUMPY > BYTES > COBS ENCODE > RADIO
# IMAGE > NUMPY > MANY NUMPY > BYTES > COBS ENCODE > RADIO > COBS DECODE ~ > NUMPY > IMAGE
