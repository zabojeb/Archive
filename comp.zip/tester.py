#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import time
import serial
from cobs import cobs, cobsr

import roslib
import sys
import rospy
import cv2
import numpy as np
from std_msgs.msg import String, UInt16
from sensor_msgs.msg import Image, CompressedImage
from geometry_msgs.msg import Twist, Point, Quaternion

radio = serial.Serial()

radio.port = '/dev/ttyUSB0'
radio.baudrate = 19200
radio.bytesize = 8
radio.timeout = 50
radio.write_timeout = 0
radio.rtscts = True
radio.dsrdtr = True
#radio.cts = True
radio.parity = "N"

radio.open()

radio.write(b'\xaa\xfa\x01')
#while True:
    #print(radio.read(8))