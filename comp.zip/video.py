#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import time
import serial
from cobs import cobs, cobsr

import roslib
import sys
import rospy
import cv2
import numpy as np
from std_msgs.msg import String, UInt16
from sensor_msgs.msg import Image, CompressedImage
from geometry_msgs.msg import Twist, Point, Quaternion

com = serial.Serial()
com.port = ("/dev/ttyACM0")
com.baudrate = 19200
com.bytesize = 8
com.timeout = None
com.open()

radio = serial.Serial()

radio.port = '/dev/ttyUSB0'
radio.baudrate = 19200
radio.bytesize = 8
radio.timeout = 50
radio.write_timeout = None
radio.drsdtr = False
radio.dtr = False
radio.parity = "N"

radio.open()

rospy.init_node('omg')

def bts_to_img(bts):
   buff = np.fromstring(bts, np.uint8)
   buff = buff.reshape(1, -1)
   img = cv2.imdecode(buff, 0)


def dosomething():
  try:
    oth = int(radio.read_until(b'\n').decode()) # - 1
    print(oth)
  except UnicodeDecodeError: print("UNICODE"); return
  except ValueError: print('value'); return

  time.sleep(0.01)
  radio.timeout = 50
  itog = bts_to_img(radio.read(oth))
  cv2.imwrite("main.jpg", itog)

dosomething()