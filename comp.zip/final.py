#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import time
import serial
from cobs import cobs, cobsr

import roslib
import sys
import rospy
import cv2
import numpy as np
from std_msgs.msg import String, UInt16
from sensor_msgs.msg import Image, CompressedImage
from geometry_msgs.msg import Twist, Point, Quaternion

com = serial.Serial()
com.port = ("/dev/ttyACM0")
com.baudrate = 19200
com.bytesize = 8
com.timeout = 15
com.open()

radio = serial.Serial()

radio.port = '/dev/ttyUSB0'
radio.baudrate = 19200
radio.bytesize = 8
radio.timeout = 15
radio.write_timeout = None
radio.drsdtr = False
radio.dtr = False
radio.parity = "N"

radio.open()

rospy.init_node('omg')
rospy.Rate = 1

def bts_to_img(bts):
    buff = np.fromstring(bts, np.uint8)
    buff = buff.reshape(1, -1)
    img = cv2.imdecode(buff, cv2.IMREAD_COLOR)
    return img

    '''
   buff = np.fromstring(bts, np.uint8)
   print(buff)
   print(buff.shape)
   img = cv2.imdecode(buff, cv2.IMREAD_GRAYSCALE)
   print(img)
   return img
    '''
def comdata():
    print('start')
    data = com.read_until(b'\r\n')
    #data = b'0;0;0;0;0;0;0;0;x\r\n'
    print(data)
    radio.write(data)

    #print(np.array(data).nbytes)
    #print(len(data))

def normal():
  try:
    start = radio.read_until(b'\xff\xd9')
    print(start)
    print(len(start))
    itog = bts_to_img(start)
    print(itog)
    cv2.imwrite("main.jpg", itog)
  except cv2.error: print('error'); return

def dosomething():
  
  try:
    oth = int(radio.readline().decode()) # - 1
    print(oth)
  except UnicodeDecodeError: print("UNICODE"); return
  except ValueError: print('value'); return

  #time.sleep(0.01)
  radio.timeout = 50
  start = radio.read(oth)
  print(start)
  itog = bts_to_img(start)
  print(itog)
  cv2.imwrite("main.jpg", itog)

  '''
  img2 = list(np.frombuffer(radio.read(oth), dtype=np.uint8))
  res = [img2[i:i+len(img2)//100] for i in range(0, len(img2), len(img2)//100)]

  itog = res
  '''

  #print(np.shape(np.array(itog)))
  #print(np.array(itog))
  #cv2.imwrite("main.jpg", np.array(itog))

#rospy.spin()
while not rospy.is_shutdown:
  print('new')
  normal()
  time.sleep(0.45)
  print('a')
  comdata()
  #time.sleep(0.05)
  print('b')
  rospy.spin()

# RADIO > COBS DECODE ~ > BYTES > NUMPY > IMAGE
# IMAGE > NUMPY > MANY NUMPY > BYTES > COBS ENCODE > RADIO > COBS DECODE ~ > NUMPY

# FIRST 1
